# Agent Orchestrator

A desktop environment for building, running, judging and recursively orchestrating fleets of AI
agents. Projects contain agents; agents hold tools, permissions and memory; agents create tasks,
create other agents, invoke each other, and schedule their own work. An independent Judge decides
whether any of it is actually finished.

Everything is local: SQLite on disk, no proprietary backend, no telemetry.

## Running it

```bash
npm install          # downloads a prebuilt better-sqlite3 for Electron; nothing compiles
npm run dev          # launch in development
npm test             # 51 tests: unit, integration and restart-recovery
npm run build        # typecheck + bundle main, preload and renderer
npm run dist:mac     # package a .dmg
```

The default provider is the **Claude Code CLI**, which uses your existing subscription. Install it
and make sure `claude` is on your `PATH` (or set `AO_CLAUDE_BIN` to its absolute path). An
Anthropic API provider is also included — add a key in Settings → Providers to enable it.

### About the native module

`better-sqlite3` is a compiled addon, and a compiled addon only loads under the ABI it was built
for. The app runs on Electron's Node; the test suite runs on yours. Two things keep that from
becoming a chore:

- **`.npmrc` pins installs to Electron's runtime.** `npm install` downloads the prebuilt Electron
  binary and never invokes `node-gyp`, so your system Node version is irrelevant to running the app.
  Keep `target` in `.npmrc` in step with the `electron` version in `package.json`.
- **`predev` and `pretest` swap the binary automatically** via `scripts/ensure-sqlite.mjs`, which
  stamps what it built so repeat runs are instant.

The one hard constraint: `npm test` needs a Node that `better-sqlite3` supports. It publishes
prebuilds up to Node 23 and cannot compile against newer V8 headers, so on Node 24+ the test suite
will tell you to switch:

```bash
nvm install 22 && nvm use 22 && npm test
```

The application itself is unaffected — it never uses your system Node.

## The shape of it

```
Electron main                          Renderer
├── db/          SQLite + Drizzle      ├── views/     dashboard, agents, graph,
├── services/    projects, agents,     │              tasks, automation, memory
│                tasks, tools, memory, ├── store      live, event-driven
│                messages, schedules,  └── api        one typed IPC channel
│                approvals, budgets
├── runtime/     agent runtime, tool
│                gateway, providers,
│                MCP bridge
└── engines/     execution manager,
                 scheduler, judge,
                 watchdog
```

The renderer has no Node access and no database handle. It calls named methods over a single
validated IPC channel and receives every state change as a pushed event, so nothing polls.

## How the loop actually works

```
mission → Orchestrator plans → creates agents → delegates tasks
                                     ↓
                             agents execute in parallel
                             (spawn children, invoke peers,
                              call tools, message each other)
                                     ↓
                                 Judge evaluates
                                ↙             ↘
                          REJECTED          APPROVED
                             ↓                  ↓
                     revision task        task complete
                             ↓                  ↓
                          re-judge      board empties → project reviewed
                                                        against its own criteria
                                                       ↙                    ↘
                                              gaps → new work           signed off
```

A task is never complete because an agent said so. The Judge reads what the agent *did* — its tool
calls, the files that exist on disk, the test output — scores it against the task's acceptance
criteria on a weighted rubric, and either approves it, sends back a revision with specific required
changes, or escalates to you. When the board empties, the project itself goes to the Judge against
its own acceptance criteria; unmet criteria become a new round of work for the Orchestrator rather
than a silent "done".

## Agents

An agent is a persistent row, not a chat session: a system prompt, a model, a toolkit, a permission
set, a place in the graph, and a task history. Anything you can do to an agent in the UI, an agent
can do to another agent through a tool — that symmetry is the point. `create_agent`, `invoke_agent`,
`delegate_task`, `create_task`, `create_schedule` and `create_tool` are ordinary tools subject to the
ordinary permission gate.

Recursion is bounded by budget and permission, not by architecture. There is no hard-coded
"developer → QA → deploy" pipeline; hierarchies emerge from what the Orchestrator decides the
mission needs. Depth, fan-out, fleet size, turns, tool calls, runtime and spend are all configurable
per project and default to conservative values.

Two rules make delegation safe:

- **An agent can only grant permissions it holds itself.** Requested permissions are intersected
  with the creator's.
- **Anything irreversible asks a human.** Dangerous tools, and any permission listed in the
  project's approval policy, block the execution until you answer in the Approvals dock.

## Providers

`ProviderAdapter` is the seam. Three implementations ship:

| Adapter | What it is |
| --- | --- |
| `claude-code` | Spawns the local Claude Code CLI. Orchestration tools reach it as an MCP server over a loopback control plane, so tool calls still flow through the permission gate. Agent permissions map onto the CLI's own tools — an agent without `FILES_WRITE` genuinely cannot write. |
| `anthropic-api` | Direct Messages API with its own tool loop. The reference implementation of the runtime contract. |
| `scripted` | Deterministic, in-process, for the test suite and dry runs. Only registered when explicitly enabled, so it can never quietly stand in for a real model. |

## Durability

Schedules live in SQLite, not in timers. On startup the scheduler works out which firings it missed
while the app was closed and applies each schedule's catch-up policy (`run_once`, `run_all` or
`skip`). Tasks caught mid-flight by a crash are requeued with an explanatory error rather than left
hanging. Executions orphaned by a hard quit are reaped by the watchdog.

## The watchdog

Every running execution is checked for silence, runaway runtime, repeated tool failures and budget
exhaustion. The smallest useful action is taken first — nudge the parent agent, then escalate to a
human, then terminate — rather than letting a stuck agent burn tokens quietly.

## Tests

```
tests/domain.test.ts        projects, recursion limits, dependencies, memory, permissions
tests/judge.test.ts         verdict parsing, weighted scoring, thresholds, panel aggregation
tests/orchestration.test.ts the full loop end to end, project sign-off, safety refusals
tests/scheduler.test.ts     cron/interval/event/dependency triggers, catch-up, restart recovery
tests/watchdog.test.ts      stuck detection, escalation, budget enforcement
```

The end-to-end test drives the deterministic provider through the real runtime: the Orchestrator
staffs a fleet, a worker spawns a child of its own and invokes a peer, files land on disk, the Judge
rejects the first attempt, a revision runs, and the second attempt is approved — then asserts the
files, the graph edges, the nested execution records and the event timeline.

## Development scripts

```bash
npx vite-node scripts/seed-demo.ts -- .demo-userdata   # build a realistic database
xvfb-run -a node scripts/visual-check.mjs              # launch the app and screenshot every view
```

`scripts/visual-check.mjs` boots the real Electron app against a seeded database with Playwright and
captures each surface to `.shots/`, which is how the UI gets reviewed rather than assumed.

## Keyboard

| | |
| --- | --- |
| `⌘K` | Command palette — navigate, run tasks, pause agents, switch projects |
| `⌘N` | New project |
| `⌘J` | Toggle the activity dock |
