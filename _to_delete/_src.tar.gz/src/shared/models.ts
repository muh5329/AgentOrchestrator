/**
 * Plain shapes shared with the renderer.
 *
 * These mirror the database rows structurally without dragging the ORM across
 * the process boundary.
 */
import type {
  AcceptanceCriterion,
  AgentRelationKind,
  AgentRole,
  AgentStatus,
  ApprovalStatus,
  CriterionScore,
  EventLevel,
  EventType,
  ExecutionStatus,
  JudgeDecision,
  MemoryKind,
  MemoryScope,
  MessageType,
  Permission,
  ProjectSettings,
  ProjectStatus,
  RetryPolicy,
  RubricDimension,
  ScheduleKind,
  TaskStatus,
  ToolKind
} from './domain'

export interface Project {
  id: string
  name: string
  description: string
  mission: string
  status: ProjectStatus
  rootPath: string | null
  instructions: string
  template: string | null
  settings: ProjectSettings
  acceptanceCriteria: AcceptanceCriterion[]
  createdAt: number
  updatedAt: number
  archivedAt: number | null
}

export interface Agent {
  id: string
  projectId: string
  parentAgentId: string | null
  name: string
  role: AgentRole
  description: string
  systemPrompt: string
  provider: string
  model: string
  temperature: number
  status: AgentStatus
  permissions: Permission[]
  depth: number
  maxChildren: number | null
  maxDepth: number | null
  isBuiltIn: boolean
  createdByAgentId: string | null
  config: Record<string, unknown>
  createdAt: number
  updatedAt: number
  lastActiveAt: number | null
}

export interface AgentGraphNode extends Agent {
  childCount: number
  openTasks: number
  runningTasks: number
  lastScore: number | null
}

export interface AgentRelationship {
  id: string
  projectId: string
  fromAgentId: string
  toAgentId: string
  kind: AgentRelationKind
  metadata: Record<string, unknown>
  createdAt: number
}

export interface AgentGraph {
  nodes: AgentGraphNode[]
  edges: AgentRelationship[]
}

export interface Task {
  id: string
  projectId: string
  agentId: string | null
  parentTaskId: string | null
  createdByAgentId: string | null
  title: string
  description: string
  status: TaskStatus
  priority: number
  acceptanceCriteria: AcceptanceCriterion[]
  context: Record<string, unknown>
  deadline: number | null
  retryPolicy: RetryPolicy | null
  attempt: number
  requiresJudge: boolean
  judgeAgentId: string | null
  revisionOfTaskId: string | null
  revisionCount: number
  score: number | null
  result: Record<string, unknown> | null
  error: string | null
  blockedReason: string | null
  scheduleId: string | null
  createdAt: number
  updatedAt: number
  startedAt: number | null
  completedAt: number | null
}

export interface Execution {
  id: string
  projectId: string
  taskId: string
  agentId: string
  parentExecutionId: string | null
  depth: number
  status: ExecutionStatus
  provider: string
  model: string
  attempt: number
  inputTokens: number
  outputTokens: number
  costUsd: number
  toolCallCount: number
  iterations: number
  summary: string | null
  error: string | null
  transcript: Array<{ at: number; kind: string; content: string; data?: Record<string, unknown> }>
  startedAt: number
  endedAt: number | null
  heartbeatAt: number
}

export interface AppEventRecord {
  id: string
  projectId: string | null
  agentId: string | null
  taskId: string | null
  executionId: string | null
  type: EventType
  level: EventLevel
  message: string
  data: Record<string, unknown>
  createdAt: number
}

export interface Message {
  id: string
  projectId: string
  fromAgentId: string | null
  toAgentId: string | null
  taskId: string | null
  type: MessageType
  priority: number
  content: string
  data: Record<string, unknown>
  readAt: number | null
  createdAt: number
}

export interface Memory {
  id: string
  projectId: string
  agentId: string | null
  taskId: string | null
  scope: MemoryScope
  kind: MemoryKind
  key: string
  content: string
  tags: string[]
  importance: number
  createdAt: number
  updatedAt: number
}

export interface Evaluation {
  id: string
  projectId: string
  taskId: string
  executionId: string | null
  judgeAgentId: string | null
  rubricId: string | null
  score: number
  decision: JudgeDecision
  criteria: CriterionScore[]
  checklist: AcceptanceCriterion[]
  issues: string[]
  requiredChanges: string[]
  summary: string
  attempt: number
  createdAt: number
}

export interface Approval {
  id: string
  projectId: string
  agentId: string | null
  taskId: string | null
  executionId: string | null
  action: string
  reason: string
  payload: Record<string, unknown>
  status: ApprovalStatus
  resolution: string | null
  decidedAt: number | null
  expiresAt: number | null
  createdAt: number
}

export interface Schedule {
  id: string
  projectId: string
  agentId: string | null
  name: string
  kind: ScheduleKind
  cron: string | null
  intervalMs: number | null
  runAt: number | null
  eventType: string | null
  dependsOnTaskId: string | null
  timezone: string
  catchupPolicy: string
  taskTemplate: Record<string, unknown>
  enabled: boolean
  lastRunAt: number | null
  nextRunAt: number | null
  runCount: number
  maxRuns: number | null
  createdAt: number
  updatedAt: number
}

export interface Toolkit {
  id: string
  projectId: string | null
  name: string
  description: string
  isBuiltIn: boolean
  createdAt: number
  updatedAt: number
}

export interface Tool {
  id: string
  toolkitId: string
  name: string
  description: string
  kind: ToolKind
  inputSchema: Record<string, unknown>
  implementation: string
  requiredPermissions: Permission[]
  timeoutMs: number
  isBuiltIn: boolean
  enabled: boolean
}

export interface Artifact {
  id: string
  projectId: string
  taskId: string | null
  executionId: string | null
  agentId: string | null
  kind: string
  title: string
  path: string | null
  content: string | null
  meta: Record<string, unknown>
  createdAt: number
}

export interface Rubric {
  id: string
  projectId: string | null
  name: string
  dimensions: RubricDimension[]
  passThreshold: number
  escalateThreshold: number
  isDefault: boolean
  createdAt: number
}

export interface ProjectStats {
  agents: number
  agentsRunning: number
  agentsIdle: number
  agentsFailed: number
  tasksTotal: number
  tasksByStatus: Record<string, number>
  pendingReviews: number
  costUsd: number
  inputTokens: number
  outputTokens: number
  executions: number
  averageScore: number | null
  requirementCoverage: number | null
  progress: number
}

export interface ProviderInfo {
  id: string
  label: string
  kind: string
  availability: { available: boolean; detail: string; version?: string } | null
}

export interface ProjectTemplateInfo {
  id: string
  name: string
  description: string
  instructions: string
  orchestratorToolkits: string[]
  orchestratorPermissions: Permission[]
  suggestedCriteria: string[]
}
